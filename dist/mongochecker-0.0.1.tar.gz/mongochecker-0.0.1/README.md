移除 mongodb 的重复数据的小工具
===
### 安装: 

```shell script
$ pip install mongochecker
```


### 运行:  

```shell script
$ mongochecker
```

## 数据贵无价 操作需谨慎